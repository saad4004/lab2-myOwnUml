
# Elevator System

A brief description of what this project does and who it's for

This is a project that shows a foundation of an elevator system that can be applied and added on in order to be implemented into various places that can use the same configuration. It contains different classes and the uses that the system can help with to achieve