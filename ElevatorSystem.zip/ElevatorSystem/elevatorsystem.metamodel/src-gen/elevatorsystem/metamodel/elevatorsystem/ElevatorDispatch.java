/**
 */
package elevatorsystem.metamodel.elevatorsystem;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Elevator Dispatch</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.ElevatorDispatch#getUpOrDown <em>Up Or Down</em>}</li>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.ElevatorDispatch#getAssignElevator <em>Assign Elevator</em>}</li>
 * </ul>
 *
 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getElevatorDispatch()
 * @model
 * @generated
 */
public interface ElevatorDispatch extends ElevatorControls {
	/**
	 * Returns the value of the '<em><b>Up Or Down</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link elevatorsystem.metamodel.elevatorsystem.ElevatorDispatch#getAssignElevator <em>Assign Elevator</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Up Or Down</em>' reference.
	 * @see #setUpOrDown(ElevatorDispatch)
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getElevatorDispatch_UpOrDown()
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorDispatch#getAssignElevator
	 * @model opposite="assignElevator"
	 * @generated
	 */
	ElevatorDispatch getUpOrDown();

	/**
	 * Sets the value of the '{@link elevatorsystem.metamodel.elevatorsystem.ElevatorDispatch#getUpOrDown <em>Up Or Down</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Up Or Down</em>' reference.
	 * @see #getUpOrDown()
	 * @generated
	 */
	void setUpOrDown(ElevatorDispatch value);

	/**
	 * Returns the value of the '<em><b>Assign Elevator</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link elevatorsystem.metamodel.elevatorsystem.ElevatorDispatch#getUpOrDown <em>Up Or Down</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Assign Elevator</em>' reference.
	 * @see #setAssignElevator(ElevatorDispatch)
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getElevatorDispatch_AssignElevator()
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorDispatch#getUpOrDown
	 * @model opposite="upOrDown"
	 * @generated
	 */
	ElevatorDispatch getAssignElevator();

	/**
	 * Sets the value of the '{@link elevatorsystem.metamodel.elevatorsystem.ElevatorDispatch#getAssignElevator <em>Assign Elevator</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Assign Elevator</em>' reference.
	 * @see #getAssignElevator()
	 * @generated
	 */
	void setAssignElevator(ElevatorDispatch value);

} // ElevatorDispatch
