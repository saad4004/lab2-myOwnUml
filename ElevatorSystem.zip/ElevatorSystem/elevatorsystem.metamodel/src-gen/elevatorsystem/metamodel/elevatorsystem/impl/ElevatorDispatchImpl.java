/**
 */
package elevatorsystem.metamodel.elevatorsystem.impl;

import elevatorsystem.metamodel.elevatorsystem.ElevatorDispatch;
import elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Elevator Dispatch</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.impl.ElevatorDispatchImpl#getUpOrDown <em>Up Or Down</em>}</li>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.impl.ElevatorDispatchImpl#getAssignElevator <em>Assign Elevator</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ElevatorDispatchImpl extends ElevatorControlsImpl implements ElevatorDispatch {
	/**
	 * The cached value of the '{@link #getUpOrDown() <em>Up Or Down</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUpOrDown()
	 * @generated
	 * @ordered
	 */
	protected ElevatorDispatch upOrDown;

	/**
	 * The cached value of the '{@link #getAssignElevator() <em>Assign Elevator</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAssignElevator()
	 * @generated
	 * @ordered
	 */
	protected ElevatorDispatch assignElevator;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ElevatorDispatchImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ElevatorsystemPackage.Literals.ELEVATOR_DISPATCH;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ElevatorDispatch getUpOrDown() {
		if (upOrDown != null && upOrDown.eIsProxy()) {
			InternalEObject oldUpOrDown = (InternalEObject) upOrDown;
			upOrDown = (ElevatorDispatch) eResolveProxy(oldUpOrDown);
			if (upOrDown != oldUpOrDown) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ElevatorsystemPackage.ELEVATOR_DISPATCH__UP_OR_DOWN, oldUpOrDown, upOrDown));
			}
		}
		return upOrDown;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ElevatorDispatch basicGetUpOrDown() {
		return upOrDown;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetUpOrDown(ElevatorDispatch newUpOrDown, NotificationChain msgs) {
		ElevatorDispatch oldUpOrDown = upOrDown;
		upOrDown = newUpOrDown;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					ElevatorsystemPackage.ELEVATOR_DISPATCH__UP_OR_DOWN, oldUpOrDown, newUpOrDown);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setUpOrDown(ElevatorDispatch newUpOrDown) {
		if (newUpOrDown != upOrDown) {
			NotificationChain msgs = null;
			if (upOrDown != null)
				msgs = ((InternalEObject) upOrDown).eInverseRemove(this,
						ElevatorsystemPackage.ELEVATOR_DISPATCH__ASSIGN_ELEVATOR, ElevatorDispatch.class, msgs);
			if (newUpOrDown != null)
				msgs = ((InternalEObject) newUpOrDown).eInverseAdd(this,
						ElevatorsystemPackage.ELEVATOR_DISPATCH__ASSIGN_ELEVATOR, ElevatorDispatch.class, msgs);
			msgs = basicSetUpOrDown(newUpOrDown, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ElevatorsystemPackage.ELEVATOR_DISPATCH__UP_OR_DOWN,
					newUpOrDown, newUpOrDown));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ElevatorDispatch getAssignElevator() {
		if (assignElevator != null && assignElevator.eIsProxy()) {
			InternalEObject oldAssignElevator = (InternalEObject) assignElevator;
			assignElevator = (ElevatorDispatch) eResolveProxy(oldAssignElevator);
			if (assignElevator != oldAssignElevator) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ElevatorsystemPackage.ELEVATOR_DISPATCH__ASSIGN_ELEVATOR, oldAssignElevator,
							assignElevator));
			}
		}
		return assignElevator;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ElevatorDispatch basicGetAssignElevator() {
		return assignElevator;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetAssignElevator(ElevatorDispatch newAssignElevator, NotificationChain msgs) {
		ElevatorDispatch oldAssignElevator = assignElevator;
		assignElevator = newAssignElevator;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					ElevatorsystemPackage.ELEVATOR_DISPATCH__ASSIGN_ELEVATOR, oldAssignElevator, newAssignElevator);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAssignElevator(ElevatorDispatch newAssignElevator) {
		if (newAssignElevator != assignElevator) {
			NotificationChain msgs = null;
			if (assignElevator != null)
				msgs = ((InternalEObject) assignElevator).eInverseRemove(this,
						ElevatorsystemPackage.ELEVATOR_DISPATCH__UP_OR_DOWN, ElevatorDispatch.class, msgs);
			if (newAssignElevator != null)
				msgs = ((InternalEObject) newAssignElevator).eInverseAdd(this,
						ElevatorsystemPackage.ELEVATOR_DISPATCH__UP_OR_DOWN, ElevatorDispatch.class, msgs);
			msgs = basicSetAssignElevator(newAssignElevator, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					ElevatorsystemPackage.ELEVATOR_DISPATCH__ASSIGN_ELEVATOR, newAssignElevator, newAssignElevator));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case ElevatorsystemPackage.ELEVATOR_DISPATCH__UP_OR_DOWN:
			if (upOrDown != null)
				msgs = ((InternalEObject) upOrDown).eInverseRemove(this,
						ElevatorsystemPackage.ELEVATOR_DISPATCH__ASSIGN_ELEVATOR, ElevatorDispatch.class, msgs);
			return basicSetUpOrDown((ElevatorDispatch) otherEnd, msgs);
		case ElevatorsystemPackage.ELEVATOR_DISPATCH__ASSIGN_ELEVATOR:
			if (assignElevator != null)
				msgs = ((InternalEObject) assignElevator).eInverseRemove(this,
						ElevatorsystemPackage.ELEVATOR_DISPATCH__UP_OR_DOWN, ElevatorDispatch.class, msgs);
			return basicSetAssignElevator((ElevatorDispatch) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case ElevatorsystemPackage.ELEVATOR_DISPATCH__UP_OR_DOWN:
			return basicSetUpOrDown(null, msgs);
		case ElevatorsystemPackage.ELEVATOR_DISPATCH__ASSIGN_ELEVATOR:
			return basicSetAssignElevator(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ElevatorsystemPackage.ELEVATOR_DISPATCH__UP_OR_DOWN:
			if (resolve)
				return getUpOrDown();
			return basicGetUpOrDown();
		case ElevatorsystemPackage.ELEVATOR_DISPATCH__ASSIGN_ELEVATOR:
			if (resolve)
				return getAssignElevator();
			return basicGetAssignElevator();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ElevatorsystemPackage.ELEVATOR_DISPATCH__UP_OR_DOWN:
			setUpOrDown((ElevatorDispatch) newValue);
			return;
		case ElevatorsystemPackage.ELEVATOR_DISPATCH__ASSIGN_ELEVATOR:
			setAssignElevator((ElevatorDispatch) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ElevatorsystemPackage.ELEVATOR_DISPATCH__UP_OR_DOWN:
			setUpOrDown((ElevatorDispatch) null);
			return;
		case ElevatorsystemPackage.ELEVATOR_DISPATCH__ASSIGN_ELEVATOR:
			setAssignElevator((ElevatorDispatch) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ElevatorsystemPackage.ELEVATOR_DISPATCH__UP_OR_DOWN:
			return upOrDown != null;
		case ElevatorsystemPackage.ELEVATOR_DISPATCH__ASSIGN_ELEVATOR:
			return assignElevator != null;
		}
		return super.eIsSet(featureID);
	}

} //ElevatorDispatchImpl
