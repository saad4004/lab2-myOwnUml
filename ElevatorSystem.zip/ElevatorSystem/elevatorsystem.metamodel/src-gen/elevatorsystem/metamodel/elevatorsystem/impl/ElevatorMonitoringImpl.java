/**
 */
package elevatorsystem.metamodel.elevatorsystem.impl;

import elevatorsystem.metamodel.elevatorsystem.ElevatorDispatch;
import elevatorsystem.metamodel.elevatorsystem.ElevatorMonitoring;
import elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Elevator Monitoring</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.impl.ElevatorMonitoringImpl#getAdministrator <em>Administrator</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ElevatorMonitoringImpl extends MinimalEObjectImpl.Container implements ElevatorMonitoring {
	/**
	 * The cached value of the '{@link #getAdministrator() <em>Administrator</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAdministrator()
	 * @generated
	 * @ordered
	 */
	protected ElevatorDispatch administrator;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ElevatorMonitoringImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ElevatorsystemPackage.Literals.ELEVATOR_MONITORING;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ElevatorDispatch getAdministrator() {
		if (administrator != null && administrator.eIsProxy()) {
			InternalEObject oldAdministrator = (InternalEObject) administrator;
			administrator = (ElevatorDispatch) eResolveProxy(oldAdministrator);
			if (administrator != oldAdministrator) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ElevatorsystemPackage.ELEVATOR_MONITORING__ADMINISTRATOR, oldAdministrator, administrator));
			}
		}
		return administrator;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ElevatorDispatch basicGetAdministrator() {
		return administrator;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAdministrator(ElevatorDispatch newAdministrator) {
		ElevatorDispatch oldAdministrator = administrator;
		administrator = newAdministrator;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					ElevatorsystemPackage.ELEVATOR_MONITORING__ADMINISTRATOR, oldAdministrator, administrator));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ElevatorsystemPackage.ELEVATOR_MONITORING__ADMINISTRATOR:
			if (resolve)
				return getAdministrator();
			return basicGetAdministrator();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ElevatorsystemPackage.ELEVATOR_MONITORING__ADMINISTRATOR:
			setAdministrator((ElevatorDispatch) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ElevatorsystemPackage.ELEVATOR_MONITORING__ADMINISTRATOR:
			setAdministrator((ElevatorDispatch) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ElevatorsystemPackage.ELEVATOR_MONITORING__ADMINISTRATOR:
			return administrator != null;
		}
		return super.eIsSet(featureID);
	}

} //ElevatorMonitoringImpl
