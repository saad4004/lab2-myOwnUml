/**
 */
package elevatorsystem.metamodel.elevatorsystem.impl;

import elevatorsystem.metamodel.elevatorsystem.BuildingManager;
import elevatorsystem.metamodel.elevatorsystem.ElevatorMonitoring;
import elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Building Manager</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.impl.BuildingManagerImpl#getElevatormonitoring <em>Elevatormonitoring</em>}</li>
 * </ul>
 *
 * @generated
 */
public class BuildingManagerImpl extends MinimalEObjectImpl.Container implements BuildingManager {
	/**
	 * The cached value of the '{@link #getElevatormonitoring() <em>Elevatormonitoring</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getElevatormonitoring()
	 * @generated
	 * @ordered
	 */
	protected ElevatorMonitoring elevatormonitoring;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected BuildingManagerImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ElevatorsystemPackage.Literals.BUILDING_MANAGER;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ElevatorMonitoring getElevatormonitoring() {
		if (elevatormonitoring != null && elevatormonitoring.eIsProxy()) {
			InternalEObject oldElevatormonitoring = (InternalEObject) elevatormonitoring;
			elevatormonitoring = (ElevatorMonitoring) eResolveProxy(oldElevatormonitoring);
			if (elevatormonitoring != oldElevatormonitoring) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ElevatorsystemPackage.BUILDING_MANAGER__ELEVATORMONITORING, oldElevatormonitoring,
							elevatormonitoring));
			}
		}
		return elevatormonitoring;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ElevatorMonitoring basicGetElevatormonitoring() {
		return elevatormonitoring;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setElevatormonitoring(ElevatorMonitoring newElevatormonitoring) {
		ElevatorMonitoring oldElevatormonitoring = elevatormonitoring;
		elevatormonitoring = newElevatormonitoring;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					ElevatorsystemPackage.BUILDING_MANAGER__ELEVATORMONITORING, oldElevatormonitoring,
					elevatormonitoring));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ElevatorsystemPackage.BUILDING_MANAGER__ELEVATORMONITORING:
			if (resolve)
				return getElevatormonitoring();
			return basicGetElevatormonitoring();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ElevatorsystemPackage.BUILDING_MANAGER__ELEVATORMONITORING:
			setElevatormonitoring((ElevatorMonitoring) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ElevatorsystemPackage.BUILDING_MANAGER__ELEVATORMONITORING:
			setElevatormonitoring((ElevatorMonitoring) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ElevatorsystemPackage.BUILDING_MANAGER__ELEVATORMONITORING:
			return elevatormonitoring != null;
		}
		return super.eIsSet(featureID);
	}

} //BuildingManagerImpl
