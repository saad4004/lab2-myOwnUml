/**
 */
package elevatorsystem.metamodel.elevatorsystem.impl;

import elevatorsystem.metamodel.elevatorsystem.Elevator;
import elevatorsystem.metamodel.elevatorsystem.ElevatorControls;
import elevatorsystem.metamodel.elevatorsystem.ElevatorDispatch;
import elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Elevator Controls</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.impl.ElevatorControlsImpl#getMovesElevator <em>Moves Elevator</em>}</li>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.impl.ElevatorControlsImpl#getControlActions <em>Control Actions</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ElevatorControlsImpl extends ElevatorImpl implements ElevatorControls {
	/**
	 * The cached value of the '{@link #getMovesElevator() <em>Moves Elevator</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMovesElevator()
	 * @generated
	 * @ordered
	 */
	protected ElevatorDispatch movesElevator;

	/**
	 * The cached value of the '{@link #getControlActions() <em>Control Actions</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getControlActions()
	 * @generated
	 * @ordered
	 */
	protected Elevator controlActions;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ElevatorControlsImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ElevatorsystemPackage.Literals.ELEVATOR_CONTROLS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ElevatorDispatch getMovesElevator() {
		if (movesElevator != null && movesElevator.eIsProxy()) {
			InternalEObject oldMovesElevator = (InternalEObject) movesElevator;
			movesElevator = (ElevatorDispatch) eResolveProxy(oldMovesElevator);
			if (movesElevator != oldMovesElevator) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ElevatorsystemPackage.ELEVATOR_CONTROLS__MOVES_ELEVATOR, oldMovesElevator, movesElevator));
			}
		}
		return movesElevator;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ElevatorDispatch basicGetMovesElevator() {
		return movesElevator;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMovesElevator(ElevatorDispatch newMovesElevator) {
		ElevatorDispatch oldMovesElevator = movesElevator;
		movesElevator = newMovesElevator;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					ElevatorsystemPackage.ELEVATOR_CONTROLS__MOVES_ELEVATOR, oldMovesElevator, movesElevator));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Elevator getControlActions() {
		if (controlActions != null && controlActions.eIsProxy()) {
			InternalEObject oldControlActions = (InternalEObject) controlActions;
			controlActions = (Elevator) eResolveProxy(oldControlActions);
			if (controlActions != oldControlActions) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ElevatorsystemPackage.ELEVATOR_CONTROLS__CONTROL_ACTIONS, oldControlActions,
							controlActions));
			}
		}
		return controlActions;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Elevator basicGetControlActions() {
		return controlActions;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setControlActions(Elevator newControlActions) {
		Elevator oldControlActions = controlActions;
		controlActions = newControlActions;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					ElevatorsystemPackage.ELEVATOR_CONTROLS__CONTROL_ACTIONS, oldControlActions, controlActions));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ElevatorsystemPackage.ELEVATOR_CONTROLS__MOVES_ELEVATOR:
			if (resolve)
				return getMovesElevator();
			return basicGetMovesElevator();
		case ElevatorsystemPackage.ELEVATOR_CONTROLS__CONTROL_ACTIONS:
			if (resolve)
				return getControlActions();
			return basicGetControlActions();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ElevatorsystemPackage.ELEVATOR_CONTROLS__MOVES_ELEVATOR:
			setMovesElevator((ElevatorDispatch) newValue);
			return;
		case ElevatorsystemPackage.ELEVATOR_CONTROLS__CONTROL_ACTIONS:
			setControlActions((Elevator) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ElevatorsystemPackage.ELEVATOR_CONTROLS__MOVES_ELEVATOR:
			setMovesElevator((ElevatorDispatch) null);
			return;
		case ElevatorsystemPackage.ELEVATOR_CONTROLS__CONTROL_ACTIONS:
			setControlActions((Elevator) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ElevatorsystemPackage.ELEVATOR_CONTROLS__MOVES_ELEVATOR:
			return movesElevator != null;
		case ElevatorsystemPackage.ELEVATOR_CONTROLS__CONTROL_ACTIONS:
			return controlActions != null;
		}
		return super.eIsSet(featureID);
	}

} //ElevatorControlsImpl
