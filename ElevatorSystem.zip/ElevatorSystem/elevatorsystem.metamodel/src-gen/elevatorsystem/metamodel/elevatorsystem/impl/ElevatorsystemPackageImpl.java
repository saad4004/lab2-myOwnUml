/**
 */
package elevatorsystem.metamodel.elevatorsystem.impl;

import elevatorsystem.metamodel.elevatorsystem.BuildingManager;
import elevatorsystem.metamodel.elevatorsystem.DeliverPerson;
import elevatorsystem.metamodel.elevatorsystem.Elevator;
import elevatorsystem.metamodel.elevatorsystem.ElevatorControls;
import elevatorsystem.metamodel.elevatorsystem.ElevatorDispatch;
import elevatorsystem.metamodel.elevatorsystem.ElevatorMonitoring;
import elevatorsystem.metamodel.elevatorsystem.ElevatorsystemFactory;
import elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage;
import elevatorsystem.metamodel.elevatorsystem.MaintenanceWorker;
import elevatorsystem.metamodel.elevatorsystem.Tenant;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class ElevatorsystemPackageImpl extends EPackageImpl implements ElevatorsystemPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass buildingManagerEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass elevatorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass elevatorMonitoringEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass maintenanceWorkerEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass tenantEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass deliverPersonEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass elevatorControlsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass elevatorDispatchEClass = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private ElevatorsystemPackageImpl() {
		super(eNS_URI, ElevatorsystemFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 *
	 * <p>This method is used to initialize {@link ElevatorsystemPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static ElevatorsystemPackage init() {
		if (isInited)
			return (ElevatorsystemPackage) EPackage.Registry.INSTANCE.getEPackage(ElevatorsystemPackage.eNS_URI);

		// Obtain or create and register package
		Object registeredElevatorsystemPackage = EPackage.Registry.INSTANCE.get(eNS_URI);
		ElevatorsystemPackageImpl theElevatorsystemPackage = registeredElevatorsystemPackage instanceof ElevatorsystemPackageImpl
				? (ElevatorsystemPackageImpl) registeredElevatorsystemPackage
				: new ElevatorsystemPackageImpl();

		isInited = true;

		// Create package meta-data objects
		theElevatorsystemPackage.createPackageContents();

		// Initialize created meta-data
		theElevatorsystemPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theElevatorsystemPackage.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(ElevatorsystemPackage.eNS_URI, theElevatorsystemPackage);
		return theElevatorsystemPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getBuildingManager() {
		return buildingManagerEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getBuildingManager_Elevatormonitoring() {
		return (EReference) buildingManagerEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getElevator() {
		return elevatorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getElevatorMonitoring() {
		return elevatorMonitoringEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getElevatorMonitoring_Administrator() {
		return (EReference) elevatorMonitoringEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getMaintenanceWorker() {
		return maintenanceWorkerEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMaintenanceWorker_User() {
		return (EReference) maintenanceWorkerEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTenant() {
		return tenantEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTenant_User() {
		return (EReference) tenantEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDeliverPerson() {
		return deliverPersonEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDeliverPerson_User() {
		return (EReference) deliverPersonEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getElevatorControls() {
		return elevatorControlsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getElevatorControls_MovesElevator() {
		return (EReference) elevatorControlsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getElevatorControls_ControlActions() {
		return (EReference) elevatorControlsEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getElevatorDispatch() {
		return elevatorDispatchEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getElevatorDispatch_UpOrDown() {
		return (EReference) elevatorDispatchEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getElevatorDispatch_AssignElevator() {
		return (EReference) elevatorDispatchEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ElevatorsystemFactory getElevatorsystemFactory() {
		return (ElevatorsystemFactory) getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		buildingManagerEClass = createEClass(BUILDING_MANAGER);
		createEReference(buildingManagerEClass, BUILDING_MANAGER__ELEVATORMONITORING);

		elevatorEClass = createEClass(ELEVATOR);

		elevatorMonitoringEClass = createEClass(ELEVATOR_MONITORING);
		createEReference(elevatorMonitoringEClass, ELEVATOR_MONITORING__ADMINISTRATOR);

		maintenanceWorkerEClass = createEClass(MAINTENANCE_WORKER);
		createEReference(maintenanceWorkerEClass, MAINTENANCE_WORKER__USER);

		tenantEClass = createEClass(TENANT);
		createEReference(tenantEClass, TENANT__USER);

		deliverPersonEClass = createEClass(DELIVER_PERSON);
		createEReference(deliverPersonEClass, DELIVER_PERSON__USER);

		elevatorControlsEClass = createEClass(ELEVATOR_CONTROLS);
		createEReference(elevatorControlsEClass, ELEVATOR_CONTROLS__MOVES_ELEVATOR);
		createEReference(elevatorControlsEClass, ELEVATOR_CONTROLS__CONTROL_ACTIONS);

		elevatorDispatchEClass = createEClass(ELEVATOR_DISPATCH);
		createEReference(elevatorDispatchEClass, ELEVATOR_DISPATCH__UP_OR_DOWN);
		createEReference(elevatorDispatchEClass, ELEVATOR_DISPATCH__ASSIGN_ELEVATOR);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		elevatorControlsEClass.getESuperTypes().add(this.getElevator());
		elevatorDispatchEClass.getESuperTypes().add(this.getElevatorControls());

		// Initialize classes, features, and operations; add parameters
		initEClass(buildingManagerEClass, BuildingManager.class, "BuildingManager", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getBuildingManager_Elevatormonitoring(), this.getElevatorMonitoring(), null,
				"elevatormonitoring", null, 0, 1, BuildingManager.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(elevatorEClass, Elevator.class, "Elevator", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(elevatorMonitoringEClass, ElevatorMonitoring.class, "ElevatorMonitoring", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getElevatorMonitoring_Administrator(), this.getElevatorDispatch(), null, "Administrator", null,
				0, 1, ElevatorMonitoring.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(maintenanceWorkerEClass, MaintenanceWorker.class, "MaintenanceWorker", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getMaintenanceWorker_User(), this.getElevatorDispatch(), null, "user", null, 0, 1,
				MaintenanceWorker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(tenantEClass, Tenant.class, "Tenant", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getTenant_User(), this.getElevatorDispatch(), null, "user", null, 0, 1, Tenant.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(deliverPersonEClass, DeliverPerson.class, "DeliverPerson", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getDeliverPerson_User(), this.getElevatorDispatch(), null, "user", null, 0, 1,
				DeliverPerson.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(elevatorControlsEClass, ElevatorControls.class, "ElevatorControls", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getElevatorControls_MovesElevator(), this.getElevatorDispatch(), null, "movesElevator", null, 0,
				1, ElevatorControls.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);
		initEReference(getElevatorControls_ControlActions(), this.getElevator(), null, "controlActions", null, 0, 1,
				ElevatorControls.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(elevatorDispatchEClass, ElevatorDispatch.class, "ElevatorDispatch", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getElevatorDispatch_UpOrDown(), this.getElevatorDispatch(),
				this.getElevatorDispatch_AssignElevator(), "upOrDown", null, 0, 1, ElevatorDispatch.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getElevatorDispatch_AssignElevator(), this.getElevatorDispatch(),
				this.getElevatorDispatch_UpOrDown(), "assignElevator", null, 0, 1, ElevatorDispatch.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Create resource
		createResource(eNS_URI);
	}

} //ElevatorsystemPackageImpl
