/**
 */
package elevatorsystem.metamodel.elevatorsystem.util;

import elevatorsystem.metamodel.elevatorsystem.*;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.Switch;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage
 * @generated
 */
public class ElevatorsystemSwitch<T> extends Switch<T> {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static ElevatorsystemPackage modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ElevatorsystemSwitch() {
		if (modelPackage == null) {
			modelPackage = ElevatorsystemPackage.eINSTANCE;
		}
	}

	/**
	 * Checks whether this is a switch for the given package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param ePackage the package in question.
	 * @return whether this is a switch for the given package.
	 * @generated
	 */
	@Override
	protected boolean isSwitchFor(EPackage ePackage) {
		return ePackage == modelPackage;
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	@Override
	protected T doSwitch(int classifierID, EObject theEObject) {
		switch (classifierID) {
		case ElevatorsystemPackage.BUILDING_MANAGER: {
			BuildingManager buildingManager = (BuildingManager) theEObject;
			T result = caseBuildingManager(buildingManager);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ElevatorsystemPackage.ELEVATOR: {
			Elevator elevator = (Elevator) theEObject;
			T result = caseElevator(elevator);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ElevatorsystemPackage.ELEVATOR_MONITORING: {
			ElevatorMonitoring elevatorMonitoring = (ElevatorMonitoring) theEObject;
			T result = caseElevatorMonitoring(elevatorMonitoring);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ElevatorsystemPackage.MAINTENANCE_WORKER: {
			MaintenanceWorker maintenanceWorker = (MaintenanceWorker) theEObject;
			T result = caseMaintenanceWorker(maintenanceWorker);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ElevatorsystemPackage.TENANT: {
			Tenant tenant = (Tenant) theEObject;
			T result = caseTenant(tenant);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ElevatorsystemPackage.DELIVER_PERSON: {
			DeliverPerson deliverPerson = (DeliverPerson) theEObject;
			T result = caseDeliverPerson(deliverPerson);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ElevatorsystemPackage.ELEVATOR_CONTROLS: {
			ElevatorControls elevatorControls = (ElevatorControls) theEObject;
			T result = caseElevatorControls(elevatorControls);
			if (result == null)
				result = caseElevator(elevatorControls);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ElevatorsystemPackage.ELEVATOR_DISPATCH: {
			ElevatorDispatch elevatorDispatch = (ElevatorDispatch) theEObject;
			T result = caseElevatorDispatch(elevatorDispatch);
			if (result == null)
				result = caseElevatorControls(elevatorDispatch);
			if (result == null)
				result = caseElevator(elevatorDispatch);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		default:
			return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Building Manager</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Building Manager</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseBuildingManager(BuildingManager object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Elevator</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Elevator</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseElevator(Elevator object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Elevator Monitoring</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Elevator Monitoring</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseElevatorMonitoring(ElevatorMonitoring object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Maintenance Worker</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Maintenance Worker</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseMaintenanceWorker(MaintenanceWorker object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Tenant</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Tenant</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTenant(Tenant object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Deliver Person</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Deliver Person</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDeliverPerson(DeliverPerson object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Elevator Controls</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Elevator Controls</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseElevatorControls(ElevatorControls object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Elevator Dispatch</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Elevator Dispatch</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseElevatorDispatch(ElevatorDispatch object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	@Override
	public T defaultCase(EObject object) {
		return null;
	}

} //ElevatorsystemSwitch
