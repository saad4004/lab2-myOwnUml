/**
 */
package elevatorsystem.metamodel.elevatorsystem;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Elevator Monitoring</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.ElevatorMonitoring#getAdministrator <em>Administrator</em>}</li>
 * </ul>
 *
 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getElevatorMonitoring()
 * @model
 * @generated
 */
public interface ElevatorMonitoring extends EObject {
	/**
	 * Returns the value of the '<em><b>Administrator</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Administrator</em>' reference.
	 * @see #setAdministrator(ElevatorDispatch)
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getElevatorMonitoring_Administrator()
	 * @model
	 * @generated
	 */
	ElevatorDispatch getAdministrator();

	/**
	 * Sets the value of the '{@link elevatorsystem.metamodel.elevatorsystem.ElevatorMonitoring#getAdministrator <em>Administrator</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Administrator</em>' reference.
	 * @see #getAdministrator()
	 * @generated
	 */
	void setAdministrator(ElevatorDispatch value);

} // ElevatorMonitoring
