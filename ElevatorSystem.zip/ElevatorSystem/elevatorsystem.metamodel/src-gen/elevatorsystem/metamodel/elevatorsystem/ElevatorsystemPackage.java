/**
 */
package elevatorsystem.metamodel.elevatorsystem;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemFactory
 * @model kind="package"
 * @generated
 */
public interface ElevatorsystemPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "elevatorsystem";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.rm2pt.com/elevatorsystem";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "elevatorsystem";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	ElevatorsystemPackage eINSTANCE = elevatorsystem.metamodel.elevatorsystem.impl.ElevatorsystemPackageImpl.init();

	/**
	 * The meta object id for the '{@link elevatorsystem.metamodel.elevatorsystem.impl.BuildingManagerImpl <em>Building Manager</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see elevatorsystem.metamodel.elevatorsystem.impl.BuildingManagerImpl
	 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorsystemPackageImpl#getBuildingManager()
	 * @generated
	 */
	int BUILDING_MANAGER = 0;

	/**
	 * The feature id for the '<em><b>Elevatormonitoring</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BUILDING_MANAGER__ELEVATORMONITORING = 0;

	/**
	 * The number of structural features of the '<em>Building Manager</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BUILDING_MANAGER_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Building Manager</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BUILDING_MANAGER_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link elevatorsystem.metamodel.elevatorsystem.impl.ElevatorImpl <em>Elevator</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorImpl
	 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorsystemPackageImpl#getElevator()
	 * @generated
	 */
	int ELEVATOR = 1;

	/**
	 * The number of structural features of the '<em>Elevator</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATOR_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Elevator</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATOR_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link elevatorsystem.metamodel.elevatorsystem.impl.ElevatorMonitoringImpl <em>Elevator Monitoring</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorMonitoringImpl
	 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorsystemPackageImpl#getElevatorMonitoring()
	 * @generated
	 */
	int ELEVATOR_MONITORING = 2;

	/**
	 * The feature id for the '<em><b>Administrator</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATOR_MONITORING__ADMINISTRATOR = 0;

	/**
	 * The number of structural features of the '<em>Elevator Monitoring</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATOR_MONITORING_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Elevator Monitoring</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATOR_MONITORING_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link elevatorsystem.metamodel.elevatorsystem.impl.MaintenanceWorkerImpl <em>Maintenance Worker</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see elevatorsystem.metamodel.elevatorsystem.impl.MaintenanceWorkerImpl
	 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorsystemPackageImpl#getMaintenanceWorker()
	 * @generated
	 */
	int MAINTENANCE_WORKER = 3;

	/**
	 * The feature id for the '<em><b>User</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAINTENANCE_WORKER__USER = 0;

	/**
	 * The number of structural features of the '<em>Maintenance Worker</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAINTENANCE_WORKER_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Maintenance Worker</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAINTENANCE_WORKER_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link elevatorsystem.metamodel.elevatorsystem.impl.TenantImpl <em>Tenant</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see elevatorsystem.metamodel.elevatorsystem.impl.TenantImpl
	 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorsystemPackageImpl#getTenant()
	 * @generated
	 */
	int TENANT = 4;

	/**
	 * The feature id for the '<em><b>User</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TENANT__USER = 0;

	/**
	 * The number of structural features of the '<em>Tenant</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TENANT_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Tenant</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TENANT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link elevatorsystem.metamodel.elevatorsystem.impl.DeliverPersonImpl <em>Deliver Person</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see elevatorsystem.metamodel.elevatorsystem.impl.DeliverPersonImpl
	 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorsystemPackageImpl#getDeliverPerson()
	 * @generated
	 */
	int DELIVER_PERSON = 5;

	/**
	 * The feature id for the '<em><b>User</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELIVER_PERSON__USER = 0;

	/**
	 * The number of structural features of the '<em>Deliver Person</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELIVER_PERSON_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Deliver Person</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DELIVER_PERSON_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link elevatorsystem.metamodel.elevatorsystem.impl.ElevatorControlsImpl <em>Elevator Controls</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorControlsImpl
	 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorsystemPackageImpl#getElevatorControls()
	 * @generated
	 */
	int ELEVATOR_CONTROLS = 6;

	/**
	 * The feature id for the '<em><b>Moves Elevator</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATOR_CONTROLS__MOVES_ELEVATOR = ELEVATOR_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Control Actions</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATOR_CONTROLS__CONTROL_ACTIONS = ELEVATOR_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Elevator Controls</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATOR_CONTROLS_FEATURE_COUNT = ELEVATOR_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Elevator Controls</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATOR_CONTROLS_OPERATION_COUNT = ELEVATOR_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link elevatorsystem.metamodel.elevatorsystem.impl.ElevatorDispatchImpl <em>Elevator Dispatch</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorDispatchImpl
	 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorsystemPackageImpl#getElevatorDispatch()
	 * @generated
	 */
	int ELEVATOR_DISPATCH = 7;

	/**
	 * The feature id for the '<em><b>Moves Elevator</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATOR_DISPATCH__MOVES_ELEVATOR = ELEVATOR_CONTROLS__MOVES_ELEVATOR;

	/**
	 * The feature id for the '<em><b>Control Actions</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATOR_DISPATCH__CONTROL_ACTIONS = ELEVATOR_CONTROLS__CONTROL_ACTIONS;

	/**
	 * The feature id for the '<em><b>Up Or Down</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATOR_DISPATCH__UP_OR_DOWN = ELEVATOR_CONTROLS_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Assign Elevator</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATOR_DISPATCH__ASSIGN_ELEVATOR = ELEVATOR_CONTROLS_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Elevator Dispatch</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATOR_DISPATCH_FEATURE_COUNT = ELEVATOR_CONTROLS_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Elevator Dispatch</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEVATOR_DISPATCH_OPERATION_COUNT = ELEVATOR_CONTROLS_OPERATION_COUNT + 0;

	/**
	 * Returns the meta object for class '{@link elevatorsystem.metamodel.elevatorsystem.BuildingManager <em>Building Manager</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Building Manager</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.BuildingManager
	 * @generated
	 */
	EClass getBuildingManager();

	/**
	 * Returns the meta object for the reference '{@link elevatorsystem.metamodel.elevatorsystem.BuildingManager#getElevatormonitoring <em>Elevatormonitoring</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Elevatormonitoring</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.BuildingManager#getElevatormonitoring()
	 * @see #getBuildingManager()
	 * @generated
	 */
	EReference getBuildingManager_Elevatormonitoring();

	/**
	 * Returns the meta object for class '{@link elevatorsystem.metamodel.elevatorsystem.Elevator <em>Elevator</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Elevator</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.Elevator
	 * @generated
	 */
	EClass getElevator();

	/**
	 * Returns the meta object for class '{@link elevatorsystem.metamodel.elevatorsystem.ElevatorMonitoring <em>Elevator Monitoring</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Elevator Monitoring</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorMonitoring
	 * @generated
	 */
	EClass getElevatorMonitoring();

	/**
	 * Returns the meta object for the reference '{@link elevatorsystem.metamodel.elevatorsystem.ElevatorMonitoring#getAdministrator <em>Administrator</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Administrator</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorMonitoring#getAdministrator()
	 * @see #getElevatorMonitoring()
	 * @generated
	 */
	EReference getElevatorMonitoring_Administrator();

	/**
	 * Returns the meta object for class '{@link elevatorsystem.metamodel.elevatorsystem.MaintenanceWorker <em>Maintenance Worker</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Maintenance Worker</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.MaintenanceWorker
	 * @generated
	 */
	EClass getMaintenanceWorker();

	/**
	 * Returns the meta object for the reference '{@link elevatorsystem.metamodel.elevatorsystem.MaintenanceWorker#getUser <em>User</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>User</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.MaintenanceWorker#getUser()
	 * @see #getMaintenanceWorker()
	 * @generated
	 */
	EReference getMaintenanceWorker_User();

	/**
	 * Returns the meta object for class '{@link elevatorsystem.metamodel.elevatorsystem.Tenant <em>Tenant</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Tenant</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.Tenant
	 * @generated
	 */
	EClass getTenant();

	/**
	 * Returns the meta object for the reference '{@link elevatorsystem.metamodel.elevatorsystem.Tenant#getUser <em>User</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>User</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.Tenant#getUser()
	 * @see #getTenant()
	 * @generated
	 */
	EReference getTenant_User();

	/**
	 * Returns the meta object for class '{@link elevatorsystem.metamodel.elevatorsystem.DeliverPerson <em>Deliver Person</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Deliver Person</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.DeliverPerson
	 * @generated
	 */
	EClass getDeliverPerson();

	/**
	 * Returns the meta object for the reference '{@link elevatorsystem.metamodel.elevatorsystem.DeliverPerson#getUser <em>User</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>User</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.DeliverPerson#getUser()
	 * @see #getDeliverPerson()
	 * @generated
	 */
	EReference getDeliverPerson_User();

	/**
	 * Returns the meta object for class '{@link elevatorsystem.metamodel.elevatorsystem.ElevatorControls <em>Elevator Controls</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Elevator Controls</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorControls
	 * @generated
	 */
	EClass getElevatorControls();

	/**
	 * Returns the meta object for the reference '{@link elevatorsystem.metamodel.elevatorsystem.ElevatorControls#getMovesElevator <em>Moves Elevator</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Moves Elevator</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorControls#getMovesElevator()
	 * @see #getElevatorControls()
	 * @generated
	 */
	EReference getElevatorControls_MovesElevator();

	/**
	 * Returns the meta object for the reference '{@link elevatorsystem.metamodel.elevatorsystem.ElevatorControls#getControlActions <em>Control Actions</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Control Actions</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorControls#getControlActions()
	 * @see #getElevatorControls()
	 * @generated
	 */
	EReference getElevatorControls_ControlActions();

	/**
	 * Returns the meta object for class '{@link elevatorsystem.metamodel.elevatorsystem.ElevatorDispatch <em>Elevator Dispatch</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Elevator Dispatch</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorDispatch
	 * @generated
	 */
	EClass getElevatorDispatch();

	/**
	 * Returns the meta object for the reference '{@link elevatorsystem.metamodel.elevatorsystem.ElevatorDispatch#getUpOrDown <em>Up Or Down</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Up Or Down</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorDispatch#getUpOrDown()
	 * @see #getElevatorDispatch()
	 * @generated
	 */
	EReference getElevatorDispatch_UpOrDown();

	/**
	 * Returns the meta object for the reference '{@link elevatorsystem.metamodel.elevatorsystem.ElevatorDispatch#getAssignElevator <em>Assign Elevator</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Assign Elevator</em>'.
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorDispatch#getAssignElevator()
	 * @see #getElevatorDispatch()
	 * @generated
	 */
	EReference getElevatorDispatch_AssignElevator();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	ElevatorsystemFactory getElevatorsystemFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link elevatorsystem.metamodel.elevatorsystem.impl.BuildingManagerImpl <em>Building Manager</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see elevatorsystem.metamodel.elevatorsystem.impl.BuildingManagerImpl
		 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorsystemPackageImpl#getBuildingManager()
		 * @generated
		 */
		EClass BUILDING_MANAGER = eINSTANCE.getBuildingManager();

		/**
		 * The meta object literal for the '<em><b>Elevatormonitoring</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BUILDING_MANAGER__ELEVATORMONITORING = eINSTANCE.getBuildingManager_Elevatormonitoring();

		/**
		 * The meta object literal for the '{@link elevatorsystem.metamodel.elevatorsystem.impl.ElevatorImpl <em>Elevator</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorImpl
		 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorsystemPackageImpl#getElevator()
		 * @generated
		 */
		EClass ELEVATOR = eINSTANCE.getElevator();

		/**
		 * The meta object literal for the '{@link elevatorsystem.metamodel.elevatorsystem.impl.ElevatorMonitoringImpl <em>Elevator Monitoring</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorMonitoringImpl
		 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorsystemPackageImpl#getElevatorMonitoring()
		 * @generated
		 */
		EClass ELEVATOR_MONITORING = eINSTANCE.getElevatorMonitoring();

		/**
		 * The meta object literal for the '<em><b>Administrator</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ELEVATOR_MONITORING__ADMINISTRATOR = eINSTANCE.getElevatorMonitoring_Administrator();

		/**
		 * The meta object literal for the '{@link elevatorsystem.metamodel.elevatorsystem.impl.MaintenanceWorkerImpl <em>Maintenance Worker</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see elevatorsystem.metamodel.elevatorsystem.impl.MaintenanceWorkerImpl
		 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorsystemPackageImpl#getMaintenanceWorker()
		 * @generated
		 */
		EClass MAINTENANCE_WORKER = eINSTANCE.getMaintenanceWorker();

		/**
		 * The meta object literal for the '<em><b>User</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MAINTENANCE_WORKER__USER = eINSTANCE.getMaintenanceWorker_User();

		/**
		 * The meta object literal for the '{@link elevatorsystem.metamodel.elevatorsystem.impl.TenantImpl <em>Tenant</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see elevatorsystem.metamodel.elevatorsystem.impl.TenantImpl
		 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorsystemPackageImpl#getTenant()
		 * @generated
		 */
		EClass TENANT = eINSTANCE.getTenant();

		/**
		 * The meta object literal for the '<em><b>User</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TENANT__USER = eINSTANCE.getTenant_User();

		/**
		 * The meta object literal for the '{@link elevatorsystem.metamodel.elevatorsystem.impl.DeliverPersonImpl <em>Deliver Person</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see elevatorsystem.metamodel.elevatorsystem.impl.DeliverPersonImpl
		 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorsystemPackageImpl#getDeliverPerson()
		 * @generated
		 */
		EClass DELIVER_PERSON = eINSTANCE.getDeliverPerson();

		/**
		 * The meta object literal for the '<em><b>User</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DELIVER_PERSON__USER = eINSTANCE.getDeliverPerson_User();

		/**
		 * The meta object literal for the '{@link elevatorsystem.metamodel.elevatorsystem.impl.ElevatorControlsImpl <em>Elevator Controls</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorControlsImpl
		 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorsystemPackageImpl#getElevatorControls()
		 * @generated
		 */
		EClass ELEVATOR_CONTROLS = eINSTANCE.getElevatorControls();

		/**
		 * The meta object literal for the '<em><b>Moves Elevator</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ELEVATOR_CONTROLS__MOVES_ELEVATOR = eINSTANCE.getElevatorControls_MovesElevator();

		/**
		 * The meta object literal for the '<em><b>Control Actions</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ELEVATOR_CONTROLS__CONTROL_ACTIONS = eINSTANCE.getElevatorControls_ControlActions();

		/**
		 * The meta object literal for the '{@link elevatorsystem.metamodel.elevatorsystem.impl.ElevatorDispatchImpl <em>Elevator Dispatch</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorDispatchImpl
		 * @see elevatorsystem.metamodel.elevatorsystem.impl.ElevatorsystemPackageImpl#getElevatorDispatch()
		 * @generated
		 */
		EClass ELEVATOR_DISPATCH = eINSTANCE.getElevatorDispatch();

		/**
		 * The meta object literal for the '<em><b>Up Or Down</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ELEVATOR_DISPATCH__UP_OR_DOWN = eINSTANCE.getElevatorDispatch_UpOrDown();

		/**
		 * The meta object literal for the '<em><b>Assign Elevator</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ELEVATOR_DISPATCH__ASSIGN_ELEVATOR = eINSTANCE.getElevatorDispatch_AssignElevator();

	}

} //ElevatorsystemPackage
