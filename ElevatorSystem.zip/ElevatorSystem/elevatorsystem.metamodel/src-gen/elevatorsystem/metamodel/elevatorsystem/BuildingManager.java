/**
 */
package elevatorsystem.metamodel.elevatorsystem;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Building Manager</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.BuildingManager#getElevatormonitoring <em>Elevatormonitoring</em>}</li>
 * </ul>
 *
 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getBuildingManager()
 * @model
 * @generated
 */
public interface BuildingManager extends EObject {
	/**
	 * Returns the value of the '<em><b>Elevatormonitoring</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Elevatormonitoring</em>' reference.
	 * @see #setElevatormonitoring(ElevatorMonitoring)
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getBuildingManager_Elevatormonitoring()
	 * @model
	 * @generated
	 */
	ElevatorMonitoring getElevatormonitoring();

	/**
	 * Sets the value of the '{@link elevatorsystem.metamodel.elevatorsystem.BuildingManager#getElevatormonitoring <em>Elevatormonitoring</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Elevatormonitoring</em>' reference.
	 * @see #getElevatormonitoring()
	 * @generated
	 */
	void setElevatormonitoring(ElevatorMonitoring value);

} // BuildingManager
