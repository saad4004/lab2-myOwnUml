/**
 */
package elevatorsystem.metamodel.elevatorsystem;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Elevator Controls</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.ElevatorControls#getMovesElevator <em>Moves Elevator</em>}</li>
 *   <li>{@link elevatorsystem.metamodel.elevatorsystem.ElevatorControls#getControlActions <em>Control Actions</em>}</li>
 * </ul>
 *
 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getElevatorControls()
 * @model
 * @generated
 */
public interface ElevatorControls extends Elevator {
	/**
	 * Returns the value of the '<em><b>Moves Elevator</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Moves Elevator</em>' reference.
	 * @see #setMovesElevator(ElevatorDispatch)
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getElevatorControls_MovesElevator()
	 * @model derived="true"
	 * @generated
	 */
	ElevatorDispatch getMovesElevator();

	/**
	 * Sets the value of the '{@link elevatorsystem.metamodel.elevatorsystem.ElevatorControls#getMovesElevator <em>Moves Elevator</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Moves Elevator</em>' reference.
	 * @see #getMovesElevator()
	 * @generated
	 */
	void setMovesElevator(ElevatorDispatch value);

	/**
	 * Returns the value of the '<em><b>Control Actions</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Control Actions</em>' reference.
	 * @see #setControlActions(Elevator)
	 * @see elevatorsystem.metamodel.elevatorsystem.ElevatorsystemPackage#getElevatorControls_ControlActions()
	 * @model
	 * @generated
	 */
	Elevator getControlActions();

	/**
	 * Sets the value of the '{@link elevatorsystem.metamodel.elevatorsystem.ElevatorControls#getControlActions <em>Control Actions</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Control Actions</em>' reference.
	 * @see #getControlActions()
	 * @generated
	 */
	void setControlActions(Elevator value);

} // ElevatorControls
