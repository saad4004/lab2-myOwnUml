
# Elevator System

A brief description of what this project does and who it's for
This is a UML diagram showing the design of an elevator system that is applicable to be used as a foundation for such a system in residental properties that have a need for such an ammenity. It is able to be scalled up with a certain restriction, such as each elevator dispatch is able to accomodate two elevators.
each relationship arrow has a different color and type of line for an easier way to differentiate different relationships between classes.